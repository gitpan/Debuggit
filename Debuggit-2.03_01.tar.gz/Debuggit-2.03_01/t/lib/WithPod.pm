# for use with t/pod_coverage.t
package WithPod;

use Debuggit;


sub foo
{
}


1;


=pod

=head2 foo

=cut
